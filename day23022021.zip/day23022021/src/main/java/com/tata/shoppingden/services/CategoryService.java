package com.tata.shoppingden.services;

import com.tata.shoppingden.models.Category;
import com.tata.shoppingden.models.Product;
import com.tata.shoppingden.repositories.CategoryRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryService {
    @Autowired
    private CategoryRepo categoryRepo;

    //insert the category
    public Category addCategory(Category category){
        if(category.getProductList()!=null){

        for(Product product : category.getProductList()){
            product.setCategory(category);
        }}
       return categoryRepo.save(category);
    }

    //select all the categories

    public List<Category> getAllCategories(){
        return categoryRepo.findAll();
    }

    //select by category id
    public Category getCategoryById(int id){
        return categoryRepo.findById(id).orElse(null);
    }

    //delete category
    public boolean deleteCategoryById(int id){
        categoryRepo.deleteById(id);
        boolean status=false;
        if(getCategoryById(id)!=null)
            status=true;
        return status;
    }

    //update category
    public Category updateCategory(Category category){
        if(category.getProductList()!=null){
        for(Product product : category.getProductList()){
            product.setCategory(category);
        }}
        return categoryRepo.save(category);
    }

}
