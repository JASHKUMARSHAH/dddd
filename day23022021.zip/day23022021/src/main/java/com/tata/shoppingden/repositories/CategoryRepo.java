package com.tata.shoppingden.repositories;

import com.tata.shoppingden.models.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepo extends JpaRepository<Category, Integer> {
}
