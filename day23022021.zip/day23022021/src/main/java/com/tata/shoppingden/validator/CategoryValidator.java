package com.tata.shoppingden.validator;

import com.tata.shoppingden.models.Category;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;


    @Component
    public class CategoryValidator implements Validator {
        @Override
        public boolean supports(Class<?> clazz) {
            // TODO Auto-generated method stub
            return false;
        }

        @Override
        public void validate(Object target, Errors errors) {
            // TODO Auto-generated method stub
            Category category = (Category) target;
            if (category.getCategoryName().length() < 5) {
                System.out.println("Error" + category.getCategoryName());
                errors.rejectValue("categoryName", "Date Error", new Object[]{"'categoryName'"}, "Category Name should be above 5 chars");
            }

        }
    }

