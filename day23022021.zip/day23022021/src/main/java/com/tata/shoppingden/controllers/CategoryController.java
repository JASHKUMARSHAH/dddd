package com.tata.shoppingden.controllers;

import com.tata.shoppingden.models.Category;
import com.tata.shoppingden.services.CategoryService;
//import com.tata.shoppingden.validator.CategoryValidator;
import com.tata.shoppingden.validator.CategoryValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class CategoryController {
    @Autowired
    private CategoryValidator validator;
    @Autowired
    private CategoryService categoryService;
    @GetMapping("/")
    public ModelAndView loadHome(){

        return new ModelAndView("index","category",new Category());
    }

    @ModelAttribute("categoryList")
    public List<Category> getCategories(){
        return this.categoryService.getAllCategories();
    }

    @PostMapping("/addcategory")
    public String addCategory(@ModelAttribute("category") @Validated Category category,
                            BindingResult bindigResult, Model model) {
        validator.validate(category, bindigResult);
        if (bindigResult.hasErrors()) {
            System.out.println(category.getCategoryName());
            return "index";
        } else {


            System.out.println(category.getCategoryName());
            categoryService.addCategory(category);
            return "redirect:/";
        }
    }




//    @PostMapping("/addcategory")
//    public String addCategory(@ModelAttribute("category") @Validated Category category,
//                              BindingResult bindingResult, Model model){
//
//        validator.validate(category, bindingResult);
//        if (bindingResult.hasErrors()) {
//            System.out.println(category.getCategoryName());
//            return "index";
//        }
//        else
//        {
//            System.out.println(category.getCategoryName());
//            categoryService.addCategory(category);
//            return "success";
//
//        }
//
//
//    }
}
